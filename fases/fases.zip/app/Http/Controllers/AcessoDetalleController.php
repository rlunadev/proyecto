<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AcessoDetalleController extends Controller
{
    //
}
