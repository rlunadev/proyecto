var ganttData = [
	{
		id: 1, name: "proyecto 1", series: [
			{ id:1,name: "modulo 1", start: new Date(2017,00,06), end: new Date(2017,00,20) },
			{ id:2,name: "modulo 2", start: new Date(2017,00,06), end: new Date(2017,00,17) },
			{ id:3,name: "modulo 3", start: new Date(2017,00,06), end: new Date(2017,00,17) }
		]
	}, 
	
];