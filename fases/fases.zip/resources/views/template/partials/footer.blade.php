@if(Auth::user())
 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>UAB 2017</strong>
  </footer>
  @endif