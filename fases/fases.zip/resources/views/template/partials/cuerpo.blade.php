<div class="jumbotron">
	<div class="container">
		<h1>HOLA A TODOS</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore, labore provident quasi? Earum, animi nobis iste eius consequuntur voluptas quos doloribus laborum recusandae! Nesciunt, rem voluptate iusto unde voluptatibus praesentium.</p>
		<p>
			<a class="btn btn-primary btn-lg">Leer Mas..</a>
		</p>
	</div>
</div>