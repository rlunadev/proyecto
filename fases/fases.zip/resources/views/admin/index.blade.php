
{{config('global.token_generated')}}