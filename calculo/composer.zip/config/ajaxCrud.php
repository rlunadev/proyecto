<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Settings for the plugin
	|--------------------------------------------------------------------------
	*/
	
	'ajax_crud_js_path' => '/bower_components/ajax_crud/dist/js/AjaxCrud.min.js',
    
);