<div class="md-modal colored-header primary md-effect-10" id="edit-modal" style="perspective: none;">
    
</div>
<div class="md-overlay"></div>