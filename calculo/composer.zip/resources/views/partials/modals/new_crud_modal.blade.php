<div class="md-modal colored-header primary md-effect-10" id="new-modal" style="perspective: none;">
    
</div>
<div class="md-overlay"></div>